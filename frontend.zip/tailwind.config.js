/** @type {import('tailwindcss').Config} */
// NativeWind는 나중에 설정합니다
module.exports = {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
};


  # 팀 B - LEGEND 초안

  This is a code bundle for 팀 B - LEGEND 초안. The original project is available at https://www.figma.com/design/UFkDYfyV7nWRjhlLu1pJfJ/%ED%8C%80-B---LEGEND-%EC%B4%88%EC%95%88.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  